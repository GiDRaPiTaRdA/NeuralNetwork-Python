10x10 handwritten digit dataset (500 images)

50 different handwritten examples of each digit 0 through 9.
Images are exactly 10x10 PNG, black strokes on white background.
labels.csv: filename, label, p0 through p99 (row-major).
Pixel value 1 = black stroke, 0 = white background.

Source: scikit-learn handwritten digits dataset (8x8 images), resized to 10x10 and binarized.
These are real handwritten digit samples, not just variations of one font.

Use the same DataLoader that reads p0...p99 and label.
Model architecture e.g. NeuralNetwork([100, 64, 32, 10]).
Keep separate test images to measure generalization.
